<!DOCTYPE html>
	<html lang="es">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Document</title>
		<link rel="stylesheet" href="css/bootstrap.min.css">
		
	</head>
	<body>
		<div class="container" >
        	
        	<div class="row">
        		<div class="col-xs-12 col-md-4">Izq</div> 
				<div class="col-xs-12 col-md-4 well">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officia cupiditate impedit id ut. Quam, aspernatur, voluptate. Ut magni incidunt excepturi error eum possimus molestias reprehenderit tempora soluta nam, numquam, omnis.</div> 
				<div class="col-xs-12 col-md-4">der</div> 
        	</div>
        	<div class="row">
        		<div class="col-xs-12 col-md-2 well"></div> 
        		<div class="col-xs-12 col-md-8">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur dolore labore tempore libero repellendus reprehenderit voluptate aspernatur ut porro itaque esse, quod quaerat ab natus molestiae aut quisquam modi cum?</div> 
        		<div class="col-xs-12 col-md-2 well"></div> 
        	</div>
        </div>
        
        
        <script src="js/jquerymin.js"></script>
        <script src="js/bootstrap.min.js"></script>
	</body>
	</html>	